package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Library.utilities;
import excelutil.readexcel;
import pages.login;


public class NewTest2 extends readexcel{

	WebDriver dr;
	utilities util;
	
	
	@BeforeClass
	public void launch() {
		
		getexcel();
		
		util=new utilities(dr);
		util.update_log("Completed Reading from excel");
		
	}

	
	  @Test(dataProvider="dp")
	  public void f(String un,String pass,String s1) {
	 
		   dr=utilities.launchbrowser("firefox");
			util.update_log("firefox browser is launch successfully"); 
		
		login l=new login(dr);
		l.login(un,pass);
		String s=l.message();
		util.update_log("login is successful with" +un+pass);
		Assert.assertTrue(s1.contains(s));
		dr.close();
		}
	  
	  @DataProvider(name="dp")
	  public String[][] dp(){
		  return testdata;
		
		  
	
	  }
}
