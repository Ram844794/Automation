package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Library.utilities;

public class login {
	
	WebDriver dr;
	utilities e;

	public login(WebDriver dr){
	this.dr=dr;
	e= new utilities(dr);
	}
	By sign=By.xpath("//a[@href='/login']");
	By username=By.xpath("//input[@name='username']");
	By password=By.xpath("//input[@name='password']");
	By submit=By.xpath("//input[@id='login']");
	By message=By.xpath("//div[@id='WelcomeContent']//child::span");

	
	
	
	public void username(String s) {
	WebElement e_id=e.waitelement(username, 20);
	dr.findElement(username).sendKeys(s);
	}
	public void password(String s) {
	WebElement e_id=e.waitelement(password, 20);
	dr.findElement(password).sendKeys(s);
	}
	public void submit() {
	WebElement e_id=e.clickable(submit, 20);
	dr.findElement(submit).click();
	}
	
	public String message() {
		
		String s=dr.findElement(message).getText();
		return s;
	}
	
	
	public void login(String un,String pass) {
	dr.findElement(sign).click();
	this.username(un);
	this.password(pass);
	this.submit();
	e.Screenshot();
	
	}
	}


