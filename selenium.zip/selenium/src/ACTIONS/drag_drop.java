package ACTIONS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class drag_drop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://demoqa.com/droppable/");

		Actions builder=new Actions(dr);

		WebElement fr=dr.findElement(By.id("draggable"));
		WebElement to=dr.findElement(By.id("droppable"));

		builder.dragAndDrop(fr,to).perform();

		String textTo=to.getText();
		if(textTo.equals("Dropped!"))
		{
		System.out.println("PASS");
		}
		else
		{
		System.out.println("FAIL");
		}


		}

	}


