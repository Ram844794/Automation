package KWDFM;

import org.openqa.selenium.WebDriver;

public class driver_script {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String kw,loc,td;
		WebDriver dr=null;
		all_webelement_fns we=new all_webelement_fns(dr);
		excel_operation excel=new excel_operation();
		for(int r=1;r<=5;r++)
		{
			kw=excel.read_excel(r,2);
			
			loc=excel.read_excel(r,3);
		
			td=excel.read_excel(r,4);
			
			switch(kw)
			{
			case "launchBrowser" :
				we.launchChrome(loc);
				break;
				
			case "enterText" :
				we.enter_txt(loc,td);
				break;
				
			case "click" :
				we.click(loc);
				break;
			}
		}

	}

}
