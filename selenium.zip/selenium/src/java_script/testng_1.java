package java_script;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class testng_1 {

  @Test
  public void f() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  WebDriver dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  
	  JavascriptExecutor js=(JavascriptExecutor) dr;
	  
	  WebElement link=dr.findElement(By.xpath("//div[@class='header-links']/ul/li[2]/a"));
	  
	  js.executeScript("arguments[0].click();", link);
	  
	  js.executeScript("document.getElementById('Email').value='ramkrishnabhavar564@gmail.com';");
	  
	  js.executeScript("document.getElementById('Password').value='Ram@9158802075';");
	  
	  WebElement btn=dr.findElement(By.xpath("//input[@value='Log in']"));
	  
	  js.executeScript("arguments[0].click();", btn);
	  
	  
  }
}
