package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



public class soucedemoTSNG {
	
	WebDriver dr;
	int a[]={1,2};                                                                          
	int i=0;
	Saucedemopr2 L;

	@BeforeClass
	 public void beforeClass() {
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr=new ChromeDriver();
	dr.get("http://www.saucedemo.com");
	L=new Saucedemopr2(dr);
	L.login("standard_user","secret_sauce");
	}

	@BeforeMethod

	 public void beforeMethod()
	{
	L.addproduct(a[i]);
	}

	@Test(priority=1)
	  public void f1()
	{
	L.verify(1);

	}

	@Test(priority=2)
	 public void f2()
	{
	L.verify(2);

	}
	
	@AfterMethod
	public void aftermethod()
	{
	if(i<1)
	{
	dr.findElement(By.xpath("//div[@class='cart_footer']//child::a")).click();
	}
	else
	{
	dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
	}
	i++;
	}
	@AfterClass
	public void afterClass()
	{
	System.out.println("in AC");
	L.info();
	}
	}







	



	


 