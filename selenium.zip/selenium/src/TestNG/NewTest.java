package TestNG;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void test1() {
	  System.out.println("in t1 : before");
	  
	  try {
		Thread.sleep(500);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
	  
	  
	  @Test
	  public void test2() {
		  System.out.println("in t2 : before");
		  
		  try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
  }
  
  
}
  }
