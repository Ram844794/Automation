package TestNG;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	demowebshop_login dr=new demowebshop_login();
  @Test(dataProvider="login_data")
  public void test1(String eid,String pwd,String exp_eid) 
	  {
		  String a_eid=dr.login(eid,pwd);
		  SoftAssert sa=new SoftAssert();
		  sa.assertEquals(a_eid, exp_eid);
		  sa.assertAll();
	  }
	  
	  @DataProvider(name="login_data")
	  public String[][] provider_data()
	  {
		  String[][] data={
				  {"ramkrishnabhavar564@gmail.com","Ram@9158802075","ramkrishnabhavar564@gmail.com"},
				  {"ramkrishnabhavar564@gmail.com","Ram@9158802075","ramkrishnabhavar56@gmail.com"},
				 
		  };
		  return data;
		                         
	  
  }
}
