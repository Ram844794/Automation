package TestNG;

import org.testng.annotations.Test;

public class priorities {
 
	
	@Test(priority=5)
  public void t1() {
	  System.out.println("Test Case 1");
  }

@Test(priority=2)
public void t2(){
	System.out.println("Test case 2");
}
	@Test(priority=1)
public void t3(){
	System.out.println("Test Case 3");
}
}
