package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class demowebshop_login {
	
	
	public String login(String eid,String pwd){
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	ChromeDriver dr=new ChromeDriver();
	
	dr.get("http://demowebshop.tricentis.com");
	
	dr.findElement(By.xpath("//a[@class='ico-login']")).click();
	dr.findElement(By.xpath("//input[@class='email']")).sendKeys(eid);
	dr.findElement(By.xpath("//input[@class='password']")).sendKeys(pwd);
	dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	String a_eid=dr.findElement(By.xpath("//a[@class='account']")).getText();
	
	return a_eid;
	
	
	
	
	
	

}
}
