package TestNG;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assert {
  @Test
  public void t1() {
	  
	  String er="chennai",ar="chennai";
	  System.out.println("in the test methiod t1");
	  SoftAssert sa=new SoftAssert();
	  sa.assertAll();
  }

  @Test
  public void t2(){
	  String er="chennai",ar="chennai1";
	  System.out.println("in the test methiod t2");
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(er,ar);
	  sa.assertAll();  
	  
  }
}
