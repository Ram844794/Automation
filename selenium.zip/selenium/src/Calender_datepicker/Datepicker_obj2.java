package Calender_datepicker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Datepicker_obj2 {
	
	static WebDriver dr;
	public void month(String s,WebDriver dr) {
	String existing;
	this.dr=dr;
	existing=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();

	while(!s.equals(existing)) {

	dr.findElement(By.xpath("//div[@class='ui-datepicker-header ui-widget-header ui-helper-clearfix ui-corner-all']//a[2]")).click();
	existing=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
	}
	}
	public void date(String s) {
	List<WebElement> all=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
	for(WebElement f:all){
	String date=f.getText();
	if(date.equalsIgnoreCase(s)) {
	f.click();
	break;
	}
	}
	}

	public static void main(String[] args) {
	String actual="12-March-2020";
	String[] arr=actual.split("[-]+");
	for (String a : arr)
	           System.out.println(a);
	String s= arr[1]+" "+arr[2];
	     String h=arr[0];
	     Datepicker_obj2 d= new Datepicker_obj2();
	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr= new ChromeDriver();
	dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
	dr.findElement(By.xpath("//input[@id='datepicker']")).click();
	d.month(s,dr);
	d.date(h);
	}



}
