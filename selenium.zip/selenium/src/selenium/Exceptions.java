package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;





public class Exceptions {
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		
		try{
			
			WebDriverWait wt=new WebDriverWait(dr,20);
			WebElement we=wt.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Log in")));
			
			
			try
			{
				
				dr.findElement(By.linkText("Log in1")).click();
			}catch (WebDriverException e){
				System.out.println("An exceptional case");
			}
		}catch (TimeoutException e){
			System.out.println("webdriver couldn't locate the element");

	}
		System.out.println("WebDriver execution continues");

}
	}
