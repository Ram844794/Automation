package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class Assignment01 {
	


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/store/Default.php");
		String s=dr.getTitle();
		String q="Online Bookstore";
		if(s.compareTo(q)==0);
		{
			System.out.println("Title Verified");
		}
			
		WebElement we =dr.findElement(By.xpath("//td[@width='250']/select"));
		
		Select sel=new Select(we);
		sel.selectByVisibleText("Databases");
		dr.findElement(By.xpath("//tr[@class='Bottom']//child::td/input")).click();
		dr.findElement(By.xpath("//a[@href='ProductDetail.php?product_id=1']")).click();
		String d=dr.findElement(By.xpath("//td[@valign='top']//child::h1")).getText();
		String c="Web Database Development";
		if(d.compareTo(c)==0);
		{
			System.out.println("Product Name Verified");
		}
		
		String p=dr.findElement(By.xpath("//td[@colspan='2']")).getText();
		System.out.println("price is: "+p);
		
		
		dr.findElement(By.xpath("//input[@name='quantity']")).clear();
		dr.findElement(By.xpath("//input[@name='quantity']")).sendKeys("2");
		
		dr.findElement(By.xpath("//input[@name='Insert1']")).click();
		
		String total =dr.findElement(By.xpath("//tr[@class='Row']//child::td[4]")).getText();
		System.out.println("total price: "+total);
		
		if(total.compareTo(p)==0)
		{
			System.out.println("Price is not Verified");
		}else{
			System.out.println("Price is Verified");
		}
		
		
		
	
			
			
		
		
		
	

	}

}
