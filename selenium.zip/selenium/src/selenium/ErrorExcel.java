package selenium;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class ErrorExcel {
 public  String readExcel(String filename,int row,int col,String sheet){
String s=null;
File f= new File(filename);
try {
FileInputStream fis= new FileInputStream(f);
XSSFWorkbook wb= new XSSFWorkbook(fis);
XSSFSheet s2= wb.getSheet(sheet);
   XSSFRow r1= s2.getRow(row);
        XSSFCell c1= r1.getCell(col);
   s= c1.getStringCellValue();
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
return s;
 }
 
 
 public void writeExcel(String filename1,int row,int col,String Sheet,String s){
String s1=null;
File f= new File(filename1);


try {
FileInputStream f1= new FileInputStream(f);
   XSSFWorkbook w1=new XSSFWorkbook(f1);

   XSSFSheet s2= w1.getSheet(Sheet);
   XSSFRow r1= s2.getRow(row);
       
   XSSFCell c1= r1.createCell(col);
c1.setCellValue(s);
FileOutputStream fos= new FileOutputStream(f);
w1.write(fos);
         
   
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
catch (IOException e) {
// TODO Auto-generated catch block
e.printStackTrace();
}


}
 public String login(String s1, String s2){

System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
WebDriver dr= new ChromeDriver();
dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();


dr.findElement(By.id("Email")).sendKeys(s1);

dr.findElement(By.id("Password")).sendKeys(s2);




dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();


String s4=dr.findElement(By.xpath("//div[@class='header-links-wrapper']//child::li[1]")).getText();
if(s1.contains("@gmail.com")||s1.contains(" ")){
if(s1.compareTo(s4)==0){
dr.close();
return s4;
}

   else{
String s=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
String s5=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
String s6=s.concat(s5);
dr.close();
return s6;

}

}else{
          String s7=dr.findElement(By.xpath("//div[@class='inputs']//child::span[1]")).getText();
          dr.close();
          return s7;
}



}
public static void main(String[] args) {
ErrorExcel g= new ErrorExcel();
String Test_result;String f="C:\\HCL_Java\\ram.xlsx";
String h="Sheet1";


for(int r=1;r<=5;r++){
String s1=g.readExcel(f, r, 0,h );

String s2=g.readExcel(f, r, 1,h);
if(s1.equals("blank")){
s1=" ";
s2=s2;
}else if(s2.equals("blank")){
s1=s1;
s2="";
}

String actualemail=g.login(s1,s2);


g.writeExcel(f, r, 3, h,actualemail);
String s4=g.readExcel(f, r, 2, h);
String s5=g.readExcel(f, r, 3, h);
int m=s5.compareTo(s4);
if(m==0){
Test_result="Pass";
}else{
Test_result="Fail";
}
g.writeExcel(f, r, 4,h,Test_result);
}

}

}