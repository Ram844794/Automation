package selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ramkrishna {
	
public String login(String e1,String e2){
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
	dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
	dr.findElement(By.id("Email")).sendKeys(e1);
	dr.findElement(By.id("Password")).sendKeys(e2);
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	String s3=dr.findElement(By.xpath("//a[@class='account']")).getText();

	return s3;
	
	
	
} 
	
public String readexcel( String filename, String sheet, int r, int c){
	
	String s1=null;
	
	File f=new File(filename);
	
	try{
		FileInputStream fis = new FileInputStream(f);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet(sheet);
		XSSFRow row = sh.getRow(r);
		XSSFCell cell = row.getCell(c);
		 s1 = cell.getStringCellValue();
		
	
	
     } catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	
     }catch (IOException e) {
      // TODO Auto-generated catch block
        e.printStackTrace();
           }return s1;
}


public void writeExcel(String filename1,int row,int col,String Sheet,String s){
	String s1=null;
	File f=new File(filename1);
	
	try{
		FileInputStream f1=new FileInputStream(f);
		XSSFWorkbook wb1=new XSSFWorkbook(f1);
		
		XSSFSheet s2=wb1.getSheet(Sheet);
		XSSFRow r1=s2.getRow(row);
		
		XSSFCell c1=r1.createCell(col);
		c1.setCellValue(s);
		FileOutputStream fos=new FileOutputStream(f);
		wb1.write(fos);
	
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();

}catch (IOException e) {
 // TODO Auto-generated catch block
   e.printStackTrace();
      }
	
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String testresult;
		String File="C:\\HCL_Java\\ram.xlsx";
		String a="Sheet1";
		
ramkrishna k=new ramkrishna();

for(int r=1;r<=5;r++){

String Email=k.readexcel(File,a,r,0);
String Pass=k.readexcel(File,a,r,1);

String s=k.login(Email,Pass);

k.writeExcel(File,r,3,a,s);
String q=k.readexcel(File,a,r,2);

int p=s.compareTo(q);

if (p==0){
	
	testresult="pass";
	
	
}else{
	testresult="fail";
	
}
k.writeExcel(File,r,4,a,testresult);


		
	
	
		
		

	}

}
}