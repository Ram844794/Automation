package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest {
	WebDriver dr;
@BeforeMethod	
public void BM(){
	
	System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
	 dr=new ChromeDriver();
	dr.get("http://demo.guru99.com/test/delete_customer.php");
	
}
	
	
  @Test
  public void f1() {
	  
	  System.out.println("t1");
  }


@Test
public void f2(){
	System.out.println("t2");
}



@AfterMethod
public void AM(){
	
		
	dr.close();
}
}