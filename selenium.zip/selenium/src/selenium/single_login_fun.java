package selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class single_login_fun {
	
	public String login(String e1,String e2){
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		
		dr.findElement(By.id("Email")).sendKeys(e1);
		dr.findElement(By.id("Password")).sendKeys(e2);
		
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		
		String em=dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();
		if(e1.contains("@gmail.com")||e1.contains(" ")){
			if(e1.compareTo(em)==0){
			dr.close();
			return em;
			}
			
			
			else{
			String em1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		String em2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		String t=em1.concat(em2);
		dr.close();
		return t;
		  }
		
	   }
		else{
			String y=dr.findElement(By.xpath("//span[@class='field-validation-error']//child::span")).getText();
	        dr.close();
	        return y;
		
     	}
		
		
	}
	
	
	public String readexcel( String filename, String sheet, int r, int c){
		
		String s1=null;
		
		File f=new File(filename);
		
		try{
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet(sheet);
			XSSFRow row = sh.getRow(r);
			XSSFCell cell = row.getCell(c);
			 s1 = cell.getStringCellValue();
			
		
		
	     } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	     }catch (IOException e) {
	      // TODO Auto-generated catch block
	        e.printStackTrace();
	           }return s1;
	}
	

public void writeExcel(String filename1,int row,int col,String Sheet,String s){
	String s1=null;
	File f=new File(filename1);
	
	
	try{
		FileInputStream f1=new FileInputStream(f);
		XSSFWorkbook wb1=new XSSFWorkbook(f1);
		
		XSSFSheet s2=wb1.getSheet(Sheet);
		XSSFRow r1=s2.getRow(row);
		
		XSSFCell c1=r1.createCell(col);
		c1.setCellValue(s);
		FileOutputStream fos=new FileOutputStream(f);
		wb1.write(fos);

		
		
} catch (FileNotFoundException e) {
// TODO Auto-generated catch block
e.printStackTrace();

}catch (IOException e) {
 // TODO Auto-generated catch block
   e.printStackTrace();
      }
	
}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		single_login_fun k=new single_login_fun();
		
		
		String File="C:\\HCL_Java\\ram.xlsx";
		String a="Sheet1";
		String testresult;
		
		
		
		
		
		

for(int r=1;r<=5;r++){

String s1=k.readexcel(File,a,r,0);
String s2=k.readexcel(File,a,r,1);


if(s1.equals("blank")){
	s1="";
	s2=s2;
	
}else if(s2.equals("blank")){
	s1=s1;
	s2="";
}
	


String actualemail=k.login(s1,s2);

k.writeExcel(File,r,3,a,actualemail);
String q1=k.readexcel(File,a,r,2);
String q2=k.readexcel(File,a, r, 3);


int p=q1.compareTo(q2);

if (p==0){
	
	testresult="pass";
	
	
}else{
	testresult="fail";
	
}
k.writeExcel(File,r,4,a,testresult);
	
}	

	}

}
