package selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelement2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		ChromeDriver dr=new ChromeDriver();
		String r= "ramkrishnabhavar564@gmail.com";
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys("ramkrishnabhavar564@@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("Ram@9158802075");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		String s=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		
		System.out.println(s2);
		System.out.println(s);
////		int m=s.compareTo(r);
//		if(m==0){
//			System.out.println("pass");
//		}else{
//			System.out.println("fail");
//		}
//		
		

	}

}
