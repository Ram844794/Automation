package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class webelement03 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
	    dr.get("http://demowebshop.tricentis.com/accessories");
	    
	    int a=1;
		
		
			dr.findElement(By.xpath("//div[@class='compare-products']//child::input")).click();
			String s1=dr.findElement(By.xpath("//div[@class='product-name']//child::h1")).getText();
			String s2=dr.findElement(By.xpath("//div[@class='product-price']//child::span")).getText();
			System.out.println(s1);
			System.out.println(s2);
		
		
	
		
		
		
		
	
		
		
		

}
}
