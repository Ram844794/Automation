package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class webelement_6 {
	
	static String q="Male";
	static String b="0 - 5";
	
	static String ram;
	public static void extract(){
		int p1=ram.indexOf(":",1);
		int p2=ram.indexOf(":",13);
		
		int p=ram.indexOf("A",1);
		String s=ram.substring(p1+2, p-1);
		String s1=ram.substring(p2+2);
		System.out.println(s);
		System.out.println(s1);
		
		int a=s.compareTo(q);
		int n=s1.compareTo(b);
		
		if (a==0 && n==0){
			System.out.println("pass");
		}else{
			System.out.println("fail");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		webelement_6 kr=new webelement_6();
		
		
		
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		
		List rb = dr.findElements(By.name("gender"));
		((WebElement) rb.get(0)).click();
		
		List rb1 = dr.findElements(By.name("ageGroup"));
		((WebElement) rb1.get(0)).click();
		
		dr.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[2]/div[2]/button")).click();
		 ram = dr.findElement(By.className("groupradiobutton")).getText();
		
		System.out.println(ram);
		
		kr.extract();
		

	}

}
