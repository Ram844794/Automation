package selenium;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment03 {
	
	
	
	public  String readExcel(String filename,int row,int col,String sheet){
		String s=null;
		File f= new File(filename);
		try {
		FileInputStream fis= new FileInputStream(f);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet s2= wb.getSheet(sheet);
		   XSSFRow r1= s2.getRow(row);
		        XSSFCell c1= r1.getCell(col);
		   s= c1.getStringCellValue();
		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		return s;
		 }
		 
	
	
	
	public void writeExcel(String filename1,int row,int col,String Sheet,String s){
		String s1=null;
		File f= new File(filename1);


		try {
		FileInputStream f1= new FileInputStream(f);
		   XSSFWorkbook w1=new XSSFWorkbook(f1);

		   XSSFSheet s2= w1.getSheet(Sheet);
		   XSSFRow r1= s2.getRow(row);
		       
		   XSSFCell c1= r1.createCell(col);
		c1.setCellValue(s);
		FileOutputStream fos= new FileOutputStream(f);
		w1.write(fos);
		         
		   
		} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
		catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		String f="C:\\HCL_Java\\swaglab.xlsx";
		String h="Sheet1";
		String TestResult;
		
		Assignment03 r=new Assignment03();
		String s1=r.readExcel(f, 1, 0, h);
		String s2=r.readExcel(f, 1, 1, h);
		
		dr.get("https://www.saucedemo.com");
		
		dr.findElement(By.xpath("//input[@id='user-name']")).sendKeys(s1);
		dr.findElement(By.xpath("//input[@id='password']")).sendKeys(s2);
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
		

		dr.findElement(By.xpath("//div[@class='inventory_item'][1]//child::button")).click();
		dr.findElement(By.xpath("//div[@class='inventory_item'][4]//child::button")).click();
		
	
		
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
		
		
		
		
		
		String Actualname1=dr.findElement(By.xpath("//a[@href='./inventory-item.html?id=4']//child::div")).getText();
		String Actualprice1=dr.findElement(By.xpath("//div[@class='cart_list']//div[3][@class='cart_item']//div[@class='item_pricebar']//child::div")).getText();
		String Actualnameprice1=Actualname1.concat(Actualprice1);
		
		
		
		
		String Actualname2=dr.findElement(By.xpath("//a[@href='./inventory-item.html?id=5']//child::div")).getText();
		String Actualprice2=dr.findElement(By.xpath("//div[@class='cart_item'][2]//div[@class='item_pricebar']//child::div")).getText();
		String Actualnameprice2=Actualname2.concat(Actualprice2);
		
		
		String ActualResult=Actualnameprice1.concat(Actualnameprice2);
		
		r.writeExcel(f, 1, 3, h, ActualResult);
		
		String ExpectedResult=r.readExcel(f, 1, 2, h);
		
		int a=ExpectedResult.compareTo(ActualResult);
		
		if(a==0){
			
			TestResult="pass";
			
		}else {
			TestResult="fail";
		}
			
		r.writeExcel(f, 1, 4, h, TestResult);
		
		
		
	
		
		
		

	}

}
