package selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class alert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demo.guru99.com/test/delete_customer.php");
	

		
		dr.findElement(By.xpath("//input[@name='cusid']")).sendKeys("RB");
		dr.findElement(By.xpath("//input[@name='submit']")).click();
		
		
		try{
			Thread.sleep(2000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
		
		Alert a1=dr.switchTo().alert();
		String s1=a1.getText();
		a1.accept();
		//a1.dismiss();
		System.out.println(s1);
		
		
		
		try{
			Thread.sleep(2000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		
		
		org.openqa.selenium.Alert a2=dr.switchTo().alert();
		String s2=a2.getText();
		a2.accept();
		//a2.dismiss
		System.out.println(s2);

	}
}


