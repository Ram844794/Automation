package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class saucedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com");
		
		
		dr.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		
		
		
		String name1=dr.findElement(By.xpath("//div[@class='inventory_item']//div[@class='inventory_item_name'][1]")).getText();
		String price1=dr.findElement(By.xpath("//div[@class='inventory_item']//div[@class='pricebar']//child::div")).getText();
		
		{
			System.out.println(name1);
			System.out.println(price1);
		}
		
		String name2=dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[2]//child::div")).getText();
		String price2=dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[3]//child::div")).getText();
		
		{
			System.out.println(name2);
			System.out.println(price2);
		}
		
		
		
		dr.findElement(By.xpath("//div[@class='inventory_item'][1]//child::button")).click();
		dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::button")).click(); 
		
		
		
		String cartname1=dr.findElement(By.xpath("//div[@class='inventory_item_label']//child::div[1]")).getText();
		String cartprice1=dr.findElement(By.xpath("//div[@class='inventory_item_price'][1]")).getText();
		
		{
			System.out.println(cartname1);
			System.out.println(cartprice1);
		}
		
		String cartname2=dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[2]//div")).getText();
		String cartprice2=dr.findElement(By.xpath("//div[@class='inventory_item'][2]//child::div[3]//div")).getText();
		
		{
			System.out.println(cartname2);
			System.out.println(cartprice2);
		}
		

	}

}
