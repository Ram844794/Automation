package selenium;

public class TestEnlogin {
	
	public void login()
	{
		System.out.println("login is succesful");
	}

	

}