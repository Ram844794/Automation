package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class test_cls {
	WebDriver dr;
	java_cls jobj;
	
	@BeforeMethod
	public void BM(){
		
		System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
		dr=new ChromeDriver();
		
		dr.get("https://www.saucedemo.com");
		jobj=new java_cls(dr);
			
	}
	
  @Test
  public void f() {
	  
	  jobj.login();
  }
}
