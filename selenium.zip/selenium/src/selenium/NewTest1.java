package selenium;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest1 {
	TestEnlogin t;
	
	@BeforeMethod
	public void BM(){
		t=new TestEnlogin();
		
		
	}
  @Test
  public void f() {
	  t.login();
  }
}
