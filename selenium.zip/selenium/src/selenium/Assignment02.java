package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		
		dr.findElement(By.xpath("//table[@class='Record']//child::tr//child::td//input")).sendKeys("Ram13@gmail.com");
		dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("Ram@13");
		dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("Ramkrishna");
		dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("Bhavar");
		dr.findElement(By.xpath("//input[@name='email']")).sendKeys("Ram13@gmail.com");
		dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("Shirdi");
		dr.findElement(By.xpath("//input[@name='address2']")).sendKeys("Maharashtra");
		dr.findElement(By.xpath("//input[@name='address3']")).sendKeys("India");
		dr.findElement(By.xpath("//input[@name='city']")).sendKeys("Shirdi");
		
		
		
WebElement we1 =dr.findElement(By.xpath("//select[@name='state_id']"));
		
		Select sel1=new Select(we1);
		sel1.selectByVisibleText("Alaska");
		
		
		dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("00013");
		
		
		
WebElement we2 =dr.findElement(By.xpath("//select[@name='country_id']"));
		
		Select sel2=new Select(we2);
		sel2.selectByVisibleText("India");
		
		
		
		
		dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("0242526");
		dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("9158802075");
		
		
		
WebElement we3 =dr.findElement(By.xpath("//select[@name='language_id']"));
		
		Select sel3=new Select(we3);
		sel3.selectByVisibleText("English");
		
		
		
		
		WebElement we4 =dr.findElement(By.xpath("//select[@name='age_id']"));
				
				Select sel4=new Select(we4);
				sel4.selectByVisibleText("18-24");
				
				
				
	WebElement we5 =dr.findElement(By.xpath("//select[@name='gender_id']"));
				
				Select sel5=new Select(we5);
				sel5.selectByVisibleText("Male");
				
				
				
WebElement we6 =dr.findElement(By.xpath("//select[@name='education_id']"));
				
				Select sel6=new Select(we6);
				sel6.selectByVisibleText("Graduate School");	
				
				
				
WebElement we7 =dr.findElement(By.xpath("//select[@name='income_id']"));
				
				Select sel7=new Select(we7);
				sel7.selectByVisibleText("$50,000 - $74,000");	
				
				
				dr.findElement(By.xpath("//textarea[@name='note']")).sendKeys("Polite");
				
				dr.findElement(By.xpath("//input[@name='Insert']")).click();
				
				
				dr.findElement(By.xpath("//tr[@class='Controls']//child::td/input")).sendKeys("Ramkrishna");
				
				dr.findElement(By.xpath("//td[@align='right']//child::input")).click();
	}

}
