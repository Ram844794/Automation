package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class java_cls {
	
	WebDriver dr;
	
	public void login()
	{
		dr.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
	}
	
	public java_cls(WebDriver dr)
	{
		this.dr=dr;
	}

}
