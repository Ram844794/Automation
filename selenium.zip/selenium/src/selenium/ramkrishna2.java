package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ramkrishna2 {
	
	
	public String login_inv(String e,String p){
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys(e);
		dr.findElement(By.id("Password")).sendKeys(p);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		String em1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		String em2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		String t=em1.concat(em2);
		System.out.println(t);
		
		return t;
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		String q="Login was unsuccessful. Please correct the errors and try again."
//				+"The credentials provided are incorrect";
		
		String d="Login was unsuccessful. Please correct the errors and try again."
				+"No customer account found";
		
		
		ramkrishna2 em =new ramkrishna2();
		String s1=em.login_inv(" ","123");
		System.out.println(s1);
		int k=d.compareTo(s1);
		
		if (k==0){
			System.out.println("Pass");
		}else{
			System.out.println("Fail");
		}

	}

}
