package Datepicker;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class datepicker {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver dr;
		String exp_month_year="April 2020";
		System.setProperty("webdriver.chrome.driver","ChromeDriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://seleniumpractise.blogspot.com/2016/08/how-to-handle-calendar-in-selenium.html");
		
		dr.findElement(By.xpath("//input[@id='datepicker']")).click();
		String act_month_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
		System.out.println(act_month_yr);
		
		while(!exp_month_year.equals(act_month_yr))
				{
			dr.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-e']")).click();
			act_month_yr=dr.findElement(By.xpath("//div[@class='ui-datepicker-title']")).getText();
			
				}
		
		List<WebElement> rb=dr.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//td"));
		for(WebElement f:rb) {
	String t =f.getText();
	if(t.equalsIgnoreCase("22")) {
		f.click();
		break;
	}
			
			
				}
			
	
		
		
		
		
		
		

	}
}


