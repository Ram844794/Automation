package Assignment01;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebRegister {
	
	

	public static String[][] testdata;
	public static int rownum;
	public static String filename="C:\\HCL_Java\\Demoweb.xlsx";
	   public static void getExcel(String sheet){
	  testdata= new String[2][5];
	    File f= new File(filename);
	    for(int rownum=1;rownum<=2;rownum++){
	  try {
	FileInputStream fis= new FileInputStream(f);
	XSSFWorkbook w=new XSSFWorkbook(fis);
	XSSFSheet s=w.getSheet(sheet);
	XSSFRow r=s.getRow(rownum);
	for(int col=0;col<=4;col++){
	XSSFCell c=r.getCell(col);
	testdata[rownum-1][col]=c.getStringCellValue();
	}
	   } catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	    }
	   
	   
	 
	   }
	   public static void Register(String fn,String ln,String email,String pass,String cp){
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  WebDriver dr= new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).click();
	  dr.findElement(By.xpath("//div[@class='page-body']//div[2]//div[2]//child::div[2]")).click();
	  dr.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(fn);
	  dr.findElement(By.xpath("//input[@name='LastName']")).sendKeys(ln);
	  dr.findElement(By.xpath("//input[@name='Email']")).sendKeys(email);
	  dr.findElement(By.xpath("//input[@name='Password']")).sendKeys(pass);
	  dr.findElement(By.xpath("//input[@name='ConfirmPassword']")).sendKeys(cp);
	  dr.findElement(By.xpath("//input[@class='button-1 register-next-step-button']")).click();
	 
	  String s2=dr.findElement(By.xpath("//a[@class='account']")).getText();
	  if(s2.contains(email)) {
	  String s1=dr.findElement(By.xpath("//div[@class='result']")).getText();
	  System.out.println(s1);
	    }else{
	    String s3=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
	  System.out.println(s3);
	    }
	  if(fn.equals("Ram")){
	  File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
	File f2= new File("C:\\HCL_Java\\anju.jpg");
	 
	try {
	FileUtils.copyFile(f1,f2);
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	  }else{
	  File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
	  File f2= new File("C:\\HCL_Java\\anju1.jpg");
	 
	try {
	FileUtils.copyFile(f1,f2);
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	  }
	  dr.close();
	   }
	}

	
	
