package Assignment01;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TsngDemoWebReg extends DemoWebRegister {
	

	@BeforeClass
	public void get(){
	getExcel("Sheet1");
	}
	//@Test
	public void print(){
	for(int r=0;r<=1;r++){
	for(int c=0;c<=3;c++){
	System.out.println(testdata[r][c]);
	}
	}
	}
	  @Test(dataProvider="register")
	  public void f(String fn,String ln,String email,String pass,String cp) {
	 Register(fn, ln, email, pass, cp);
	  }
	  @DataProvider(name="register")
	  public String[][] register(){
	 return testdata;  }
	}

	
	
	
	

  
