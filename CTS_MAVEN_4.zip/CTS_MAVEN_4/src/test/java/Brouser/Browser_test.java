package Brouser;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Browser_test extends DriverFactory {
	
	
	DriverFactory b;
	String url="https://www.saucedemo.com/";
	WebDriver dr;
	
	
	
  @Test(priority=0)
  public void chrome_login() {
	  dr=DriverFactory.launch_Browser("CHROME", url);
  }
	  
	  
	  
	  @Test(priority=2)
	  public void firefox_login() {
		  dr=DriverFactory.launch_Browser("FIREFOX", url);
  }
}
