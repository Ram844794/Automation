package POMS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import UTILITIES.utilities;

public class test_AUT_login extends utilities  {
	
	
	AUT_login_page loginpage;
	AUT_home_page homepage;
	
	@BeforeClass
	public void launchBrouser()
	{
		 launchbrowser("chrome");
	}
	
	@Test(priority=0)
	public void test_login_page()
	{
		loginpage=new AUT_login_page(dr);
		String login_page_title=loginpage.get_title();
		Assert.assertTrue(login_page_title.contains("Shop"));
	}
	
	@Test(priority=2)
	public void test_home_page()
	{
		loginpage.do_login("ramkrishnabhavar564@gmail.com", "Ram@9158802075");
		homepage =new AUT_home_page(dr);
		String actual_eid=homepage.get_displayed_eid();
		Assert.assertTrue(actual_eid.contains("ramkrishnabhavar564@gmail.com"));
		
	}

}
