package POM_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class homepage {
	
WebDriver dr;
	
	By profile_name=By.xpath("//div[@class='media-body media-middle']//p[@id='user-name']");
	By designation=By.xpath("//span[@class='job-title']");
	By personalize=By.xpath("//span[@class='icomoon-user']");
	By Add=By.xpath("//li[@class='personalise__add-more']//button");
	By acquisition=By.xpath("//span[@id='316743-label']");
	By digital=By.xpath("//span[@id='317709-label']");
	By outreach=By.xpath("//span[@id='316861-label']");
	By finish=By.xpath("/html/body/div/div/div[3]/div/span/button");
	By added_acquiusition=By.xpath("//div[@class='personalise clearfix']//child::button[1]");
	
	public homepage(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String prof()
	{
		return dr.findElement(profile_name).getText();
	}
	
	public String des()
	{
		return dr.findElement(designation).getText();
	}
	
	public void pr()
	{
		dr.findElement(personalize).click();
	}
	
	public void ad()
	{
		dr.findElement(Add).click();
		
	}
	
	public void acui()
	{
		dr.findElement(acquisition).click();
	}
	
	public void digi()
	{
		dr.findElement(digital).click();
	}
	
	public void out()
	{
		dr.findElement(outreach).click();
	}
	
	public void fin()
	{
		dr.findElement(finish).click();
	}
	
	public String aa()
	{
		return dr.findElement(added_acquiusition).getText();
	}


}


