package POM_pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.Baseclass.utilities;

public class cognizant_TESTNG extends utilities {
	
	WebDriver dr;
	login lg;
	homepage hp;
	
	@BeforeClass
	public void launchbrowser()
	{
		dr=LaunchBrowser();
		getexcel();
	}
	
	@Test(dataProvider="dp")
	public void test1(String e, String un,String pw)
	{
		lg=new login(dr);
		//dr.findElement(By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]")).sendKeys("844794@cognizant.com");
		lg.first_action(un, pw,e);
		//dr.findElement(By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]")).sendKeys("844794@cognizant.com");
		hp=new homepage(dr);
		
		String profile_name=hp.prof();
		String designation=hp.des();
		System.out.println(profile_name);
		System.out.println(designation);
		hp.pr();
		hp.ad();
		hp.acui();
		hp.digi();
		hp.out();
		hp.fin();
		String acqui_name=hp.aa();
		System.out.println(acqui_name);
	}
	
	@DataProvider
	public String[][] dp() throws IOException{
		return testdata;
	}

	}

 
