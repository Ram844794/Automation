package POM_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.Baseclass.utilities;

public class login {
	
	By email=By.xpath("/html/body/div/form[1]/div/div/div[1]/div[3]/div/div/div/div[2]/div[2]/div/input[1]");
	By username=By.xpath("//input[@name='UserName']");
	By password=By.xpath("//input[@name='Password']");
	By Log=By.xpath("//input[@class='desktopsubmit']");
	
	
	WebDriver dr;
	utilities u;
	
	public login(WebDriver dr)
	{
		this.dr=dr;
		u=new utilities();
	}
	
	public void em(String e)
	{
		dr.findElement(email).sendKeys(e);
	}
	
	public void user(String un)
	{
		dr.findElement(username).sendKeys(un);
	}
	
	public void pass(String pw)
	{
		dr.findElement(password).sendKeys(pw);
	}
	
	public void LOG_ON()
	{
		dr.findElement(Log).click();
	}
	
	
	public void first_action(String un,String pw,String e)
	{
		
		this.em(e);
		this.user(un);
		this.pass(pw);
		this.LOG_ON();
	}
}




