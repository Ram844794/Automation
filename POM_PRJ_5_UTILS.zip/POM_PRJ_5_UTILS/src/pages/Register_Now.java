package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.ExplicitCode;

public class Register_Now {
	
	WebDriver dr;
	Title t= new Title(dr);
	ExplicitCode e;
	signup s= new signup(dr);
	Register r= new Register(dr);
	public Register_Now( WebDriver dr){
	this.dr=dr;
	e= new ExplicitCode(dr);
	}
	By user=By.xpath("//div[@id='Catalog']//following::input[2]");
	By pass=By.xpath("//div[@id='Catalog']//following::input[3]");
	By cofpass=By.xpath("//div[@id='Catalog']//following::input[4]");
	By fname=By.xpath("//div[@id='Catalog']//following::input[5]");
	By lname=By.xpath("//div[@id='Catalog']//following::input[6]");
	By email=By.xpath("//div[@id='Catalog']//following::input[7]");
	By phone=By.xpath("//div[@id='Catalog']//following::input[8]");
	By add1=By.xpath("//div[@id='Catalog']//following::input[9]");
	By add2=By.xpath("//div[@id='Catalog']//following::input[10]");
	By city=By.xpath("//div[@id='Catalog']//following::input[11]");
	By state=By.xpath("//div[@id='Catalog']//following::input[12]");
	By zip=By.xpath("//div[@id='Catalog']//following::input[13]");
	By country=By.xpath("//div[@id='Catalog']//following::input[14]");
	By save=By.xpath("//input[@id='save']");
	public void username(String un) {
	WebElement e_id=e.waitelement(user, 20);
	e_id.sendKeys(un);
	}
	public void password(String un) {
	WebElement e_id=e.waitelement(pass, 20);
	dr.findElement(pass).sendKeys(un);
	}
	public void resetpass(String un) {
	WebElement e_id=e.waitelement(cofpass, 20);
	dr.findElement(cofpass).sendKeys(un);
	}
	public void firstname(String un) {
	WebElement e_id=e.waitelement(fname, 20);
	dr.findElement(fname).sendKeys(un);
	}
	public void lastname(String un) {
	WebElement e_id=e.waitelement(lname, 20);
	dr.findElement(lname).sendKeys(un);
	}
	public void Email(String un) {
	WebElement e_id=e.waitelement(email, 20);
	dr.findElement(email).sendKeys(un);
	}
	public void phonenumber(String un) {
	WebElement e_id=e.waitelement(phone, 20);
	dr.findElement(phone).sendKeys(un);
	}
	public void address1(String un) {
	WebElement e_id=e.waitelement(add1, 20);
	dr.findElement(add1).sendKeys(un);
	}
	public void address2(String un) {
	WebElement e_id=e.waitelement(add2, 20);
	dr.findElement(add2).sendKeys(un);
	}
	public void Cnmae(String un) {
	WebElement e_id=e.waitelement(city, 20);
	dr.findElement(city).sendKeys(un);
	}
	public void Sname(String un) {
	WebElement e_id=e.waitelement(state, 20);
	dr.findElement(state).sendKeys(un);
	}
	public void Zip(String un) {
	WebElement e_id=e.waitelement(zip, 20);
	dr.findElement(zip).sendKeys(un);
	}
	public void Country(String un) {
	WebElement e_id=e.waitelement(country, 20);
	dr.findElement(country).sendKeys(un);
	}

	public String registration(String uname,String pass,String cp,String fname,String lnmae,String email,String ph,String add1,String add2,String city,String state,String zip,String country) {



	this.username(uname);
	this.password(pass);

	this.resetpass(cp);
	this.firstname(fname);
	this.lastname(lnmae);
	this.Email(email);
	this.phonenumber(ph);
	this.address1(add1);
	this.address2(add2);
	this.Cnmae(city);
	this.Sname(state);
	this.Zip(zip);
	this.Country(country);
	dr.findElement(save).click();
	e.Screenshot();
	String s= dr.getTitle();
	return s;
	}
	}


