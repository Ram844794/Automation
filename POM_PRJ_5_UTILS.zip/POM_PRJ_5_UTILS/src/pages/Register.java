package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.ExplicitCode;

public class Register {
	
	WebDriver dr;
	ExplicitCode e;
	Title t= new Title(dr);
	public Register(WebDriver dr){
	this.dr=dr;
	e= new ExplicitCode(dr);
	}
	By reg=By.xpath("//div[@id='Catalog']//child::a[1]");
	public String register() {
	WebElement e_id=e.clickable(reg, 20);
	e_id.click();
	String s= dr.getTitle();
	return s;
	}
	}


