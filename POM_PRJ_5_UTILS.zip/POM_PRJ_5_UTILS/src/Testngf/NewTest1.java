package Testngf;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pages.Register;
import pages.Register_Now;
import pages.login;
import pages.signup;

public class NewTest1 {
	WebDriver dr;
	String ti="JPetStore Demo";
	String re="Your account has been created. Please try login !!";
	String lo="Welcome Ramkrishna !";


	@BeforeClass
	public void launch() {

	System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	dr= new ChromeDriver();
	dr.get("https://jpetstore.cfapps.io/catalog");
	dr.manage().window().maximize();
	}
	@Test(priority=0)
	public void f() {
	signup s=new signup(dr);
	s.sign();

	  }
	  @Test(priority=2)
	  public void f1() {
	 Register r= new Register(dr);
	 String p=r.register();
	 Assert.assertTrue(ti.contains(p));
	  }
	  @Test(priority=3)
	  public void f2() {
	 Register_Now r1= new Register_Now(dr);
	 
	String p=  r1.registration("samadhan","ramk@123", "ramk@123", "Ramkrishna", "patil","ramkrishnabh1998@gmail.com", "9158802075", "1/2270", "1/2270","shirdi", "MH", "510446", "India");
	Assert.assertTrue(ti.contains(p));

	  }
	  @Test(priority=4)
	  public void f3() {
	 login l=new login(dr);
	 String s=l.verify();
	Assert.assertEquals(re,s);
	  l.login("samadhan", "ramk@123");
	  String s1=l.verify1();
	  Assert.assertTrue(lo.contains(s1));
	  dr.close();
	  }
	}


  
