package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class shop_clk {
	
	WebDriver dr;
	utilities e;
	
	public shop_clk() {
		this.dr=dr;
		e=new utilities();
	}
	
	By shop=By.xpath("//ul[@id='main-nav']//li[1]");
	
	public void clk_shop() {
		WebElement w8=e.clickable(shop, 20);
		w8.click();
	}
	
	public void CLICKING_SHOP() {
		this.clk_shop();
	}

}
