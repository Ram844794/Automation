package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class product_page {
	
	WebDriver dr;
	utilities e;
	
	public product_page() {
		this.dr=dr;
		e=new utilities();
	}
	
	By selenium=By.xpath("//ul[@class='product-categories']//li[4]/a");
	
	public void sel() {
		WebElement w9=e.clickable(selenium, 20);
		w9.click();
	}
	
	public void CLICKLIG_SELENIUM() {
		this.sel();
	}

}
