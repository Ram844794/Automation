package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class Register_page {
	
	WebDriver dr;
	utilities e;
	
	public Register_page(WebDriver dr) {
		this.dr=dr;
		e=new utilities();
	}
	
	
	By Email=By.xpath("//div[@class='u-column2 col-2']//input[@id='reg_email']");
	By Password=By.xpath("//div[@class='u-column2 col-2']//input[@id='reg_password']");
	By Register=By.xpath("//p[@class='woocomerce-FormRow form-row']//input[3]");
	
	
	
    public void email(String emR) {
	WebElement w2=e.waitelement(Email, 20);
	w2.sendKeys(emR);
     }

     public void pass(String pwR) {
	  WebElement w3=e.waitelement(Password, 20);
	  w3.sendKeys(pwR);
     }

     public void reg() {
	WebElement w4=e.clickable(Register, 20);
	w4.click();
	
     }
     
     public void DO_REGISTER(String emR,String pwR) {
 		this.email(emR);
 		this.pass(pwR);
 		this.reg();
 	}
		
	}
	


