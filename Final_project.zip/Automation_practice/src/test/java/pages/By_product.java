package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class By_product {
	
	WebDriver dr;
	utilities e;
	
	public By_product() {
		this.dr=dr;
		e=new utilities();
	}
	
	By Add_basket=By.xpath("//a[@rel='nofollow']");
	By Demo_site=By.xpath("//nav[@id='main-nav-wrap']//li[5]");
	
	public void add_basket() {
		WebElement w10=e.clickable(Add_basket, 20);
		w10.click();
	}
	
	public void demo_site() {
		WebElement w11=e.clickable(Demo_site, 20);
		w11.click();
	}
	
	public void DO_ACTION() {
		this.add_basket();
		this.demo_site();
	}
	

}
