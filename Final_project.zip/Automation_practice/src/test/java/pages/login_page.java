package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class login_page {
	
	WebDriver dr;
	utilities e;
	
	public login_page() {
		this.dr=dr;
		e=new utilities();
	}
	
	By username =By.xpath("//div[@class='u-column1 col-1']//input[@id='username']");
	By passwordL =By.xpath("//div[@class='u-column1 col-1']//input[@id='password']");
	By login = By.xpath("//p[@class='form-row']//input[3]");
	
	
	public void user(String emL) {
		WebElement w5=e.waitelement(username, 20);
		w5.sendKeys(emL);
	}
	
	public void passL(String pwL) {
		WebElement w6=e.waitelement(passwordL, 20);
		w6.sendKeys(pwL);
	}
	
	public void log() {
		WebElement w7=e.waitelement(login, 20);
		w7.click();
	}
	
	public void DO_LOGIN(String emL,String pwL) {
		this.user(emL);
		this.passL(pwL);
		this.log();
	}

}
