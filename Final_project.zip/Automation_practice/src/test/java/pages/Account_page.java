package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import UTILITIES.utilities;

public class Account_page {
	
	WebDriver dr;
	utilities e;
	
	public Account_page(WebDriver dr) {
		this.dr=dr;
		e=new utilities();
	}
	
	By Account=By.xpath("//div[@id='headerwrap']//ul[@id='main-nav']//following::li[1]/a");
	
	
	public void acc() {
		WebElement w1=e.clickable(Account, 20);
		w1.click();
		
	}
	
	public void clk_acc() {
		this.acc();
	}

}
