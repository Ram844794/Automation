package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import UTILITIES.utilities;

public class submit_form {
	
	WebDriver dr;
	utilities e;
	
	public submit_form() {
		this.dr=dr;
		e=new utilities();
	}
	
	By Firstname=By.xpath("//input[@placeholder='First Name']");
	By Lastname=By.xpath("//input[@placeholder='Last Name']");
	By Address=By.xpath("//textarea[@class='form-control ng-pristine ng-untouched ng-valid']");
	By Email=By.xpath("//input[@type='email']");
	By Phone=By.xpath("//input[@type='tel']");
	By Gender=By.xpath("//input[@value='Male']");
	By Hobbie=By.xpath("//input[@value='Movies']");
	By Language=By.xpath("//div[@id='msdd']");
	By Skill=By.xpath("//select[@id='Skills']");
	By Country=By.xpath("//select[@id='countries']");
	By Year=By.xpath("//select[@id='yearbox']");
	By Month=By.xpath("//select[@placeholder='Month']");
	By Date=By.xpath("//select[@id='daybox']");
	By Password=By.xpath("//input[@id='firstpassword']");
	By ConfirmPassword=By.xpath("//input[@id='secondpassword']");
	By Submit=By.xpath("//button[@id='submitbtn']");
	
	
	public void firstname(String fn) {
		WebElement w11=e.waitelement(Firstname, 20);
		w11.sendKeys(fn);
	}
	
	public void lastname(String ln) {
		WebElement w12=e.waitelement(Lastname, 20);
		w12.sendKeys(ln);

	}
	
	public void address(String ad) {
		WebElement w13=e.waitelement(Address, 20);
		w13.sendKeys(ad);
	}
	
	public void email(String em) {
		WebElement w14=e.waitelement(Email, 20);
		w14.sendKeys(em);
	}
	
	public void phone(String ph) {
		WebElement w15=e.waitelement(Phone, 20);
		w15.sendKeys(ph);
	}
	
	public void gender() {
		WebElement w16=e.clickable(Gender, 20);
		w16.click();
	}
	
	public void hobbies() {
		WebElement w17=e.clickable(Hobbie, 20);
		w17.click();
	}
	
	public void language(String lg) {
		WebElement w18=e.waitelement(Language, 20);
		w18.sendKeys(lg);
	}
	
	public void skill() {
		WebElement w19=e.clickable(Skill, 20);
		w19.click();
		Select sel1=new Select(w19);
		sel1.selectByVisibleText("Engineering");
	}
	
	public void country() {
		WebElement w20=e.clickable(Country, 20);
		w20.click();
		Select sel2=new Select(w20);
		sel2.selectByVisibleText("India");
	}
	
	public void year() {
		WebElement w21=e.clickable(Year, 20);
		w21.click();
		Select sel3=new Select(w21);
		sel3.selectByVisibleText("1998");
	}
	
	public void month() {
		WebElement w22=e.clickable(Month, 20);
		w22.click();
		Select sel4=new Select(w22);
		sel4.selectByVisibleText("January");
	
	}
	
	public void date() {
		WebElement w23=e.clickable(Date, 20);
		w23.click();
		Select sel5=new Select(w23);
		sel5.selectByVisibleText("13");
	}
	
	public void password(String pw) {
	WebElement w24=e.waitelement(Password, 20);
	w24.sendKeys(pw);
	
	}
	
	public void confirmpass(String cnp) {
		WebElement w25=e.waitelement(ConfirmPassword, 20);
		w25.sendKeys(cnp);
	}
	
	public void submit() {
		WebElement w26=e.clickable(Submit, 20);
		w26.click();
	}
	
	public void DO_SUBMIT(String fn,String ln,String ad,String em,String ph,String lg,String pw,String cnp) {
		this.firstname(fn);
		this.lastname(ln);
		this.address(ad);
		this.email(em);
		this.phone(ph);
		this.gender();
		this.hobbies();
		this.language(lg);
		this.skill();
		this.country();
		this.year();
		this.month();
		this.date();
		this.password(pw);
		this.confirmpass(cnp);
		this.submit();
	}
	
	
	
	

}
