package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="src\\main\\resources\\FEATURE", glue="STEP_DEF")

public class cum_test_runner1 extends AbstractTestNGCucumberTests {

}
