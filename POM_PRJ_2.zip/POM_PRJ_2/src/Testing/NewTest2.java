package Testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import HOMEPAGE.HP1;
import HOMEPAGE.HP2;
import HOMEPAGE.gettitle;

public class NewTest2 {
 
	WebDriver dr;
	gettitle g;
	HP1 h;
	HP2 h1;
	
	
  @BeforeClass
  public void launch() {
	  
	  System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
		dr= new FirefoxDriver();
		dr.get("http://examples.codecharge.com/Store/Default.php");
  }
  
  @Test(priority=0)
  public void t1() {
	  h= new HP1(dr);
	  String s=h.title();
	  h.searching();
	  Assert.assertTrue(s.contains("Online Bookstore"));
  }
  
  @Test(priority=1)
  public void t2() {
	g=new gettitle(dr);
	h1=new HP2(dr);
	String s=g.gettitle();
	String s1=h1.Verifyname();
	 Assert.assertTrue(s.contains("SearchResults"));
	 Assert.assertTrue(s1.contains("Perl and CGI for the World Wide Web"));
	 
  }
}
