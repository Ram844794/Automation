package HOMEPAGE;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HP2 {
	
	WebDriver dr;
	gettitle g;
			
	public HP2(WebDriver dr) {
		this.dr=dr;
		g=new gettitle(dr);
	}
	
	By name= By.xpath("//a[@href='ProductDetail.php?product_id=3']");
	
	public String Verifyname() {
		String s=dr.findElement(name).getText();
		return s;
	}
			


}
