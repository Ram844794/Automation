package HOMEPAGE;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HP1 {
	
	WebDriver dr;
	gettitle g;
	
	public HP1(WebDriver dr) {
		this.dr=dr;
		g=new gettitle(dr);
	}
	
	By pr=By.xpath("//select[@name='category_id']//following::option[2]");
	By cl=By.xpath("//input[@name='DoSearch']");
	
	
	public void programming()
	{
		dr.findElement(pr).click();
	}
	
	public void clicking()
	{
		dr.findElement(cl).click();
	}
	
	public void searching() {
		this.programming();
		this.clicking();
		
		
	}
	public String title() {
		return dr.getTitle();
	}
	

}
