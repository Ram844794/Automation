package HOMEPAGE;

import org.openqa.selenium.WebDriver;

public class gettitle {
	
	WebDriver dr;
	
	public gettitle(WebDriver dr) {
		this.dr=dr;
	}
	
	public String  gettitle() {
		String s= dr.getTitle();
		return s;
		}

}
