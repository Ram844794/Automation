package POMS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.Baseclass.utilities;

public class search_page {
	
	By search=By.xpath("//input[@id='search']");
	By submit=By.xpath("//input[@name='submit-search']");
	By sort=By.xpath("//div[@class='sortBy_block fl'][1]//child::a[contains(@id,'sbSelector')]");
	By price=By.xpath("//a[@href='#Price High-Low']");
	By select=By.xpath("/html/body/div[2]/div[2]/div/div[2]/div[1]/div/div/div[3]/div/div[3]/ul/li[1]/div[4]/div[5]/p");
	By size=By.xpath("/html/body/div[2]/div[3]/div[1]/div[2]/div[2]/div[4]/div[1]/div[1]/select");
	By SHORT=By.xpath("/html/body/div[2]/div[3]/div[1]/div[2]/div[2]/div[4]/div[1]/div[1]/select/option[2]");
	By quantity=By.xpath("//li[@class='pdp-product-increase pdp-qtty pdp-qtty-boss-increase']");
	By cart=By.xpath("//input[@class='pdp-addtobag']");
	By cart_value=By.xpath("//span[@class='number-items boss-number-items nonzero-items']");
	
	WebDriver dr;
	utilities e;
	
	public search_page(WebDriver dr)
	{
		this.dr=dr;
		e=new utilities();
	}
	
	public void search1(String t)
	{
		dr.findElement(search).sendKeys(t);
	}
	
	public void submit1()
	{
		dr.findElement(submit).click();
	}
	
	public void sort1()
	{
		dr.findElement(sort).click();
	}
	
	public void price1()
	{
		dr.findElement(price).click();
	}
	
	public void select1()
	{
		dr.findElement(select).click();
	}
	
	public void size1()
	{
		dr.findElement(size).click();
	}
	
	public void SHORT1()
	{
		dr.findElement(SHORT).click();
	}
	
	public void quantity1()
	{
		dr.findElement(quantity).click();
	}
	
	public void cart1()
	{
		dr.findElement(cart).click();
	}
	
	public String cart_value1()
	{
		return dr.findElement(cart_value).getText();
	}
	
	public void tuxedo()
	{
		this.search1("tuxedo");
		this.submit1();
		this.sort1();
		this.price1();
		this.select1();
		this.size1();
		this.SHORT1();
		this.quantity1();
		this.cart1();
	}

}
