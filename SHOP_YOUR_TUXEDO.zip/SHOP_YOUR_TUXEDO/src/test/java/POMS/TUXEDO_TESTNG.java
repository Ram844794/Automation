package POMS;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Baseclass.utilities;

public class TUXEDO_TESTNG extends utilities {
	
	WebDriver dr;
	search_page sp;
	
	@BeforeClass
	public void launchbrowser()
	{
		dr=LaunchBrowser();
	}
	
  @Test
  public void f() {
	  
	  sp=new search_page(dr);
	  sp.tuxedo();
	  String value=sp.cart_value1();
	  Assert.assertTrue(value.contains("2"));
	  
  }
}
