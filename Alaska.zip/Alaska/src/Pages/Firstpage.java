package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.ExplicitCode;

public class Firstpage {
	
	WebDriver dr;
	ExplicitCode e;
	public  Firstpage(WebDriver dr) {
		this.dr=dr;
		e=new ExplicitCode();
	}
	
	By whale=By.xpath("//a[@href='/alaska-whale-watching-and-wildlife']");
	By mainu=By.xpath("//div[@class='headerMainToolbar__menu']//button");
	By plan=By.xpath("//a[@id='rciHeaderSideNavMenu-1']");
	By close=By.xpath("//button[@id='rciHeaderCloseSidenav']/figure");
	By ship=By.xpath("//div[@class='headerTopNav__base']//div[2]/a");
	By Ropsody=By.xpath("/html/body/div[1]/div[2]/div[1]/div/div[6]/div/section/div/div[16]/a/div/figure/div");
	By deck=By.xpath("//div[@class='filterSetDestination__container']//div[3]");
	By eight=By.xpath("//select[@id='deckDropdown']/option[7]");
	By Royal=By.xpath("/html/body/div[1]/div[2]/div/div[1]/div/div/div[2]/section/section[2]/section[1]/div[2]/section[5]/h4");
	
	
	public boolean whalef() {
		boolean w=dr.findElement(whale).isDisplayed();
		return w;
	}
	
	
public void mainuf() {
	WebElement we=e.clickElement(mainu, 100);
	we.click();
}
	
		public void planf() {
	WebElement we=e.clickElement(plan, 100);
			we.click();
			
		}
		
		public void closef() {
			WebElement we=e.clickElement(close, 100);
			we.click();	
		}
		
		
		public void shipf() {
			WebElement we= e.clickElement(ship, 100);
			we.click();
			
		}
		
		public void Rospodyf() {
			WebElement we=e.clickElement(Ropsody, 100);
			we.click();
			
		}
		
		public void deckf() {
			WebElement we=e.clickElement(deck, 100);
			we.click();
			
		}
		
		public void eightf() {
			WebElement we=e.clickElement(eight, 100);
			we.click();
			
		}
		
		public String Royalf() {
			WebElement we=e.waitElement(Royal, 100);
			String n=we.getText();
			return n;
			
		}
		
		public void rp() {
			this.mainuf();
			this.planf();
			this.closef();
			this.shipf();
			this.Rospodyf();
			this.deckf();
			this.eightf();
		
		}
	}


