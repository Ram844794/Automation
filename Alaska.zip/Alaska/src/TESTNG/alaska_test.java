package TESTNG;

import javax.swing.text.Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.Firstpage;
import Utilities.ExplicitCode;

public class alaska_test extends ExplicitCode {
	
	WebDriver dr;
	Firstpage fp;
	
	@BeforeClass
	public void Launchbrowser() {
		launchbrowser();
	}
  @Test
  public void t1() {
	  
	 fp=new Firstpage(dr);
	 try {
		 boolean b=dr.findElement(By.xpath("//a[@href='/alaska-whale-watching-and-wildlife']")).isDisplayed();
		 Assert.assertTrue(b);
	 }catch(Exception e1) {
		 System.out.println("whale watching tour");
	 }

	 fp.rp();
	 
	 String r=fp.Royalf();
	 Assert.assertTrue(r.contains("Royal"));
	 
	  
	  
  }
}
