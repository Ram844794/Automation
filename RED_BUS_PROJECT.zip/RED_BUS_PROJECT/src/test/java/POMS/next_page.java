package POMS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class next_page {
	
	WebDriver dr;
	
	By check_btn= By.xpath("/html/body/section/div[2]/div[1]/div/div[2]/div[1]/div/div[2]/ul[3]/li[3]/label[1]");
	By name= By.xpath("//div[@class='clearfix bus-item-details'][1]//child::div[2]");
	By price= By.xpath("//div[@class='fare d-block'][1]//span");
	
	
	public next_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String get_name()
	{
		return dr.findElement(name).getText();
	}
	
	public String get_price()
	{
		return dr.findElement(price).getText();
	}
	
	public void check_box()
	{
		dr.findElement(check_btn).click();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	

}
