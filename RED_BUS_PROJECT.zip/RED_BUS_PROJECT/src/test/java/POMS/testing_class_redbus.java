package POMS;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import UTILITIES.utilities;

public class testing_class_redbus extends utilities  {
	
	WebDriver dr;
	booking_page bp;
	next_page np;

	@BeforeClass
	public void launchBrouser()
	{
		 dr=launchbrowser("chrome");
		 getexcel();
		 
	}
	
	@Test(dataProvider="dp")
	public void t1(String fr,String to,String a)
	{
      bp=new booking_page(dr);
      bp.searching(fr, to,a);
      
      np=new next_page(dr);
      
      np.check_box();
      String n= np.get_name();
      String p=np.get_price();
      
      System.out.println(n);
      System.out.println(p);
      
   
	}
	
	@DataProvider
	public String[][] dp() throws IOException{
		return testdata;
	}

	}


