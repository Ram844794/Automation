package POMS;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class booking_page {
	
	By From= By.xpath("//input[@id='src']");
	By from2= By.xpath("//ul[@class='autoFill']//li[1]");
	
	By To= By.xpath("//input[@id='dest']");
	By TO2= By.xpath("//ul[@class='autoFill']//child::li[1]");
	
	By bus=By.xpath("//button[@id='search_btn']");
	

	
	
	
	WebDriver dr;
	
	public booking_page(WebDriver dr) {
		this.dr=dr;
	}
	
	public void give_from(String fr) 
	{
		dr.findElement(From).sendKeys(fr);
		dr.findElement(from2).click();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public void give_to(String to)
	{
		dr.findElement(To).sendKeys(to);
		dr.findElement(TO2).click();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	public void clk_btn()
	{
		dr.findElement(bus).click();
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
	
	
	public void set_date(String m)
	{
		String t=m.substring(1,(m.length()-1));
		String ex_date=t;
		String act_date;
		String[]a=ex_date.split("-",5);
		String da=a[1]+" "+a[2];
		String day=a[0];
		
		dr.findElement(By.xpath("//label[@for='onward_cal']")).click();
		act_date=dr.findElement(By.xpath("//div[@id='rb-calendar_onward_cal']/table/tbody/tr[1]/td[2]")).getText();
		System.out.println(act_date);
		while(!da.equalsIgnoreCase(act_date))
		{
			dr.findElement(By.xpath("//div[@class='rb-calendar']/table/tbody/tr[1]/td[3]/child::button")).click();
			act_date=dr.findElement(By.xpath("//div[@id='rb-calendar_onward_cal']/table/tbody/tr[1]/td[2]")).getText();
		}
		
		List<WebElement> ab=dr.findElements(By.xpath("//div[@id='rb-calendar_onward_cal']/table//child::td"));
		
		for(WebElement e1:ab)
		{
			String b=e1.getText();
			if(b.equalsIgnoreCase(day))
			{
				e1.click();
				break;
			}
		}
		
	}
	
	
	
	public void searching(String fr,String to,String a)
	{
		
		
		this.give_from(fr);
		this.give_to(to);
		this.set_date(a);
		this.clk_btn();
	

}
}
