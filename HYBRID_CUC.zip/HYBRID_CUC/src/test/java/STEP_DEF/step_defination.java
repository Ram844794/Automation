package STEP_DEF;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import POMS.AUT_home_page;
import POMS.AUT_login_page;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class step_defination {
	
	WebDriver dr;
	@Given("^Browser is launched and login page displayed$")
	public void browser_is_launched_and_login_page_displayed() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
	
	}

	@When("^User enters login credentials and click on login$")
	public void user_enters_login_credentials_and_click_on_login() throws Throwable {
		AUT_login_page lg=new AUT_login_page(dr);
		lg.do_login("ramkrishnabhavar564@gmail.com","Ram@9158802075");

	  
	}

	@Then("^Successful login happens and profile name displayed correctly$")
	public void successful_login_happens_and_profile_name_displayed_correctly() throws Throwable {
		
		AUT_home_page hp=new AUT_home_page(dr);
		String e=hp.get_displayed_eid();
		if(e.contains("ramkrishnabhavar564@gmail.com")) {
			System.out.println("test sucesss");
		}else {
			System.out.println("test fails");
		}
		
		
	    
	}

}
