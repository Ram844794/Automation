package EXCEL_UTILITY;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_arr {
	
	public static String[][] testdata=new String[1][3];
	public static int  r,c;


	public static void  getexcel()
	{

	System.out.println("Ram");
	String filename="C:\\HCL_java\\DATA.xlsx";
	String   Sheet="Sheet1";
	int r=1;
	try {
	File f=new File(filename);
	FileInputStream fin= new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fin);
	XSSFSheet sh= wb.getSheet(Sheet);
	for( r=0;r<1;r++ )
	{
	XSSFRow row=sh.getRow(r);
	for(c=0;c<=2;c++)
	{
	// XSSFRow row=sh.getRow(r);
	XSSFCell cell1 =row.getCell(c);
	testdata[r][c] =cell1.getStringCellValue();
	// System.out.println(testdata[r][c]);
	XSSFCell cell2 =row.getCell(c);
	testdata[r][c] =cell2.getStringCellValue();
//	//System.out.println(testdata[r][c]);

	System.out.println(testdata[r][c]);

	}


	}

	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}

}
}
