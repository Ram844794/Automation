package POMS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AUT_home_page {
	
WebDriver dr;
	
	By profile_xp= By.xpath("//a[@class='account']");
	
	public AUT_home_page(WebDriver dr)
	{
		this.dr=dr;
	}
	
	public String get_displayed_eid()
	{
		return dr.findElement(profile_xp).getText();
		
	}

}


