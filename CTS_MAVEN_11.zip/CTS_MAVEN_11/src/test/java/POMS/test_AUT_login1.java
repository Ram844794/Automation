package POMS;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import UTILITIES.utilities;

public class test_AUT_login1 extends utilities  {
	
	
	AUT_login_page loginpage;
	AUT_home_page homepage;
	
	@BeforeClass
	public void launchBrouser()
	{
		 launchbrowser("chrome");
		 getexcel();
		 
	}
	
	@Test(dataProvider="dp")
	public void t1(String u,String p,String e)
	{
      loginpage=new AUT_login_page(dr);
      loginpage.do_login(u, p);
      
      homepage=new AUT_home_page(dr);
      String actual_eid=homepage.get_displayed_eid();
      Assert.assertTrue(actual_eid.contains(e));
	}
	
	@DataProvider
	public String[][] dp() throws IOException{
		return testdata;
	}

	}


