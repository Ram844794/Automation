package com.Baseclass;

import java.util.concurrent.TimeUnit;

public class utilities {
	
	protected static WebDriver dr;
	static int counter=1;
	
	
	
	public static WebDriver LaunchBrowser()
	
	String ch_browser="src\\test\\resource\\chromedriver_v79.exe";
	{
		System.setProperty("webdriver.driver.chrome",ch_browser);
		dr=new ChromeDiver;
		dr.get("https://be.cognizant.com/");
		dr.manage().window().maximaize();
		dr.manage().timeouts().implicitlyWait(20.TimeUnit.SECONDS);
	}

}
