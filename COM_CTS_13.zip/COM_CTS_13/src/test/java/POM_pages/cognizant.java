package POM_pages;

import org.testng.annotations.Test;

public class cognizant {
  @Test
  public void f() {
  }
}
